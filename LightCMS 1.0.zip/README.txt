Restrict access to /news folder, and to db.sqlite file (if you want).Make sure that /news folder is 777 or has all permissions.
There is NO installer. Everything can be changed using config(config.php) or using admin panel.
