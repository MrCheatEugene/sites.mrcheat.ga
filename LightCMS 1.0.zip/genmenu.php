<?php
//include 'openDB.php';
  include'config.php'; 
 include'menu.php';
$one= @$_POST['one'];
$two= @$_POST['two'];
$three= @$_POST['three'];
$four= @$_POST['four'];
$onetext= @$_POST['onetext'];
$twotext= @$_POST['twotext'];
$threetext= @$_POST['threetext'];
$fourtext= @$_POST['fourtext'];
$password=@$_POST['pass'];
$login=@$_POST['login'];

if (empty($one) AND empty($onetext) ==true){
	$oneEmpty =true;

}else{
	$oneEmpty=false;
}
if (empty($two) AND empty($twotext) ==true){
	$twoempty =true;
	
}else{
	$twoempty=false;
}
if (empty($three) AND empty($threetext) ==true){
	$threeempty =true;
	
}else{
	$threeempty=false;
}
if (empty($four) AND empty($fourtext) ==true){
	$fourempty =true;
	
}else{
	$fourempty=false;
}
if ($oneEmpty == false){
	$html1='<a href="'.$one.'"> <button> '.$onetext.' </button></a>';
}

if ($twoempty == false){
	$html2='<a href="'.$two.'"> <button> '.$twotext.' </button></a>';

}
if ($threeempty == false){
	$html3='<a href="'.$three.'"> <button> '.$threetext.' </button></a>';

}
if ($fourempty == false){
	$html4='<a href="'.$four.'"> <button> '.$fourtext.' </button></a>';
}
if ($loginadmin == $login AND $passwordadmin == $password){
$html = $html1.$html2.$html3.$html4;
	header('Location: /list.php');

}else{

}
file_put_contents("menu.php", $html)
?>
<script src="//js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
						
<form action="genmenu.php" method="POST">
	<div align="left">
Link 1
<input name="one" type="text">

Link 2
<input name="two" type="text">
Link 3
<input name="three" type="text">

Link 4
<input name="four" type="text"></div>
<div align="left">
Text 1
<input name="onetext" type="text">
Text 2
<input name="twotext" type="text">
Text 3
<input name="threetext" type="text">
Text 4
<input name="fourtext" type="text">
</div>
**If you dont want to use some of the buttons in menu, just leave inputs for them empty**
In case of safety, please enter admin login and password .  <input type="text" name="login"> <input type="password" name="pass">
<input type="submit">
</form>