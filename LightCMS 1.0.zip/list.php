<?php

class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('db.sqlite');
    }
}
$db = new MyDB();
echo'<table border="1">
   <caption> Articles</caption>
   <tbody><tr>
    <th>ID of article</th>
    <th>Filename</th>
    <th>Buttons</th>

   </tr>
   <tr> <td> -</td> <td> -</td> <td><a href="create.php" >Create</a></td></tr>
   <tr> <td> -</td> <td> -</td> <td><a href="genmenu.php" >Re-Create menu</a></td></tr>
   
  ';
$result = $db->query(" SELECT id FROM news ORDER BY id DESC LIMIT 0,1");

while ($row = $result->fetchArray()) 
{
    $getId= $row["id"];
}
$result = $db->query(" SELECT * FROM news ORDER BY id DESC LIMIT ".$getId);
while ($row = $result->fetchArray()) 
{
   echo'<tr>
   <td><a href="'.$row['file'].'">'.$row['id'].'</a></td><td>'.$row['file'].'</td><td><a href="edit.php?id='.$row['id'].'">Edit </a> <a href="delete.php?id='.$row['id'].'">Delete </a> </td></tr>';

}
echo'   </tbody></table>';