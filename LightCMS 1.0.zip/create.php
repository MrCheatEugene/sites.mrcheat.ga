<?php
//include 'openDB.php';

class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('db.sqlite');
    }
}
$db = new MyDB();
 include'config.php'; 
//$db->exec('CREATE TABLE news (id INTEGER,file STRING)');
//$db->exec("INSERT INTO news (id,file) VALUES (0,'/news/0.html')");
$result = $db->query(" SELECT id FROM news ORDER BY id DESC LIMIT 0,1");

while ($row = $result->fetchArray()) 
{
    $getId= $row["id"];
}
$id=$getId+1;
echo $id;

$post= @$_POST['html'];
$isEmpty= empty($post);
if ($isEmpty == true){
}else{
//$db->exec
	$password=@$_POST['pass'];
$login=@$_POST['login'];
//echo $post
if ($loginadmin == $login AND $passwordadmin == $password){
 //fopen("news/".$id.".html",  "r");
if (file_exists ("news/".$id.".html"  ) == true){
$id=$id+1;
file_put_contents("news/".$id.".html", $post);

$db->query("INSERT INTO news (id,file) VALUES (".$id.",'/news/".$id.".html')");
header('Location: /list.php');


}else{
file_put_contents("news/".$id.".html", $post);
$db->query("INSERT INTO news (id,file) VALUES (".$id.",'/news/".$id.".html')");
header('Location: /list.php');

}

}else{header('Location: /list.php');
}
}
?>
<script src="//js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
						
<form action="create.php" method="POST">

<textarea style="width: 300px; height: 100px;" name="html"></textarea>
In case of safety, please enter admin login and password .  <input type="text" name="login"> <input type="password" name="pass">
<input type="submit">
</form>