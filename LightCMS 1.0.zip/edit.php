<?php
$html=@$_GET['id'];

if (empty($html) == true){
	
}else{

class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('db.sqlite');
    }
}
$db = new MyDB();
$result = $db->query(" SELECT * FROM news WHERE id = ".$html);

while ($row = $result->fetchArray()) 
{
  
$file = $row["file"];
}		

$html= file_get_contents("http://127.0.0.1".$file);

$htmml=@$_POST['html'];
if (empty($htmml) == false){
$password=@$_POST['pass'];
$login=@$_POST['login'];
include'config.php';
if ($loginadmin == $login AND $passwordadmin == $password){
file_put_contents(getcwd().$file, $htmml);
//echo $htmml;
header('Location: /list.php');
}else{
	header('Location: /list.php');

}
} }
//

?>
<script src="//js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
<form  method="POST"> <textarea style="width: 300px; height: 100px;" name="html"> <?php echo $html; ?></textarea>In case of safety, please enter admin login and password .  <input type="text" name="login"> <input type="password" name="pass"> <input type="submit"></form>