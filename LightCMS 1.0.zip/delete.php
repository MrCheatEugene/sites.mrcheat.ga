<?php
$html=@$_GET['id'];
$password=@$_POST['pass'];
$login=@$_POST['login'];

if (empty($html) == false){
	require'config.php';
if ($loginadmin == $login AND $passwordadmin == $password){
class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('db.sqlite');
    }
}
$db = new MyDB();

$result = $db->query(" SELECT * FROM news WHERE id = ".$html);

while ($row = $result->fetchArray()) 
{
  
$file = $row["file"];
}	

$db->query(" DELETE FROM news WHERE id = ".$html);
unlink(getcwd().$file);
header('Location: /list.php');

}else{

}
}
?>

<form method="POST">In case of safety, please enter admin login and password .  <input type="text" name="login"> <input type="password" name="pass"><input type="submit"></form>