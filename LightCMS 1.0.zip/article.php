﻿<html>

<head>
<meta http-equiv="Content-Language" content="ru">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<title><?php include'config.php'; echo $sitename?></title>
<!--mstheme--><link rel="stylesheet" href="evrg1011-1251.css">
<meta name="Microsoft Theme" content="evrgreen 1011">
<div align="center">
<?php include'menu.php'; ?>
</div>
  <style>
   .ramka {
    width: 600px;	height: 400px; /* Размеры */
    background: #FFFFFF; /* Цвет фона */
    outline: 2px solid #000; /* Чёрная рамка */
    border: 3px solid #fff; /* Белая рамка */
    border-radius: 9px; /* Радиус скругления */

   }
   .title{
   font-size: 24px
   }
      .text{
      color: black;
   font-size: 18px;
   }
  </style>
</head>

<body>

<?php
echo'
</body>

</html>';

class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('db.sqlite');
    }
}
$db = new MyDB();
$times=1;
$id = @$_GET['id'];
$result = $db->query(" SELECT * FROM news  WHERE id =".$id." ORDER BY id DESC LIMIT ".$times." ");

while ($row = $result->fetchArray()) 
{
    $id= $row["id"];
$file = $row["file"];
}
echo'
<p>          </p>

<div align="center"> <div   class="ramka">
<div align="left">
<iframe src="'.$file.'" style="   width: 899px;	height:999px; "frameborder="0"> </iframe>
 </div> 
 </div>';