﻿<html>

<head>
<meta http-equiv="Content-Language" content="ru">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<title><?php include'config.php'; echo $sitename?></title>
<!--mstheme--><link rel="stylesheet" href="evrg1011-1251.css">
<meta name="Microsoft Theme" content="evrgreen 1011">
<div align="center">
<?php include'menu.php'; ?>
</div>
  <style>
   .ramka {
    width: 600px;	height: 400px; /* Размеры */
    background: #FFFFFF; /* Цвет фона */
    outline: 2px solid #000; /* Чёрная рамка */
    border: 3px solid #fff; /* Белая рамка */
    border-radius: 9px; /* Радиус скругления */

   }
   .title{
   font-size: 24px
   }
      .text{
      color: black;
   font-size: 18px;
   }
  </style>
</head>

<body>
<?php class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('db.sqlite');
    }
}
$db = new MyDB();
$times=1;
while($times < $articlesonindex ){

$result = $db->query(" SELECT * FROM news ORDER BY id DESC LIMIT ".$times."");

while ($row = $result->fetchArray()) 
{
    $id= $row["id"];
$file = $row["file"];
}
echo'

<div align="center"> <div   class="ramka">
<div align="left">
<a href="article.php?id='.$id.'"><p class="text">#'.$id.'</p></a>
<iframe src="'.$file.'" style="   width: 599px; height: 399px; "frameborder="0"> </iframe>
 </div> 
 
 </div><p>          </p>';
 $times=$times+1;}
 ?>
</body>

</html>