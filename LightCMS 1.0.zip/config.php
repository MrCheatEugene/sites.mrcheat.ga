<?php

 $sitename = "Test Site";// Title of the site(uses everywhere)
$articlesonindex = 5; // Max. amount of articles on index page. If you have less than 5 articles, change it. Otherwise, it may cause errors.
$articlesonnews = 10;// Max. amount of articles on news page. If you have less than 10 article, change it. Otherwise, it may cause errors.
$loginadmin="admen";// Login for admin  - DO NOT USE FOR IT LOGINS LIKE admin, root, etc.
$passwordadmin="lightcms3955yxq22"// Password for admin - CHANGE RIGHT NOW!!!!!
?>x