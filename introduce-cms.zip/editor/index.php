﻿<div style="margin: 40px; background-color: lightgray;">
<a style="display:inline-block;text-decoration: none; text-indent: 20%;  color:black; font-size: 12px;"href="/"><h1>Главная</h1></a>
<a style="display:inline-block;text-decoration: none; text-indent: 50%; color:black; font-size: 12px;"href="/editor/"><h1>Редактор</h1></a></div>


<?php
if(empty($_GET)){
	echo('<script src="//js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
<style type="text/css">
	body{
		font: 100% Arial;
	}


</style>	

<h1>Introduce CMS - Редактор страниц</h1>
<form>
</br> Файл интро(пишите default если не знаете что это)
</br>
	<input type="text" name="intro"></input>
</br> ID страницы(может быть буквенно-цифренным, не используйте уже существующий!)
</br>
	<input type="text" name="id"></input>
</br> Название страницы</br>
		<input type="text" name="title"></input>
	</br> Содержимое страницы</br>
	<textarea style=" color:white;width:900px; height: 300px;" name="text"> </textarea>
	</br>	<input type="checkbox" name="disable" >Отключить страницу</input>
			</br>
	<input type="submit" name=""></input>
</form>	
');
}
	if(empty($_GET)){die("Не было получено никаких данных. ");}else{
	try{
	$text=$_GET['text'];
	$title=$_GET['title'];
	$intro=$_GET['intro'];
if(empty($_GET['disable'])){
$page_state="off";
}else{
	$page_state=$_GET['disable'];

}
		$page_id=$_GET['id'];
	}catch(Exception $e){
		die( "Ошибка настройки переменных! Проверьте, заполнены ли все поля! Полная ошибка: ".$e);
	}
	if(empty($_get['mode'])){
	$page_data=array();
	$page_data['title']=$title;
	$page_data['intro']=$intro;
	if($page_state=="on"){
	$page_data['disabled']="yes";
	}else{
	$page_data['disabled']="no(change to yes if you want to disable it)";	
	}
	$page_data=json_encode($page_data,JSON_UNESCAPED_UNICODE);
	echo '<script>
	function downloadFile(){
		let link = document.createElement("a");
	link.download = "page_'.$page_id.'_data.json";

	let blob = new Blob(['."'".$page_data."'".'], {type: "application/json"});

	let reader = new FileReader();
	reader.readAsDataURL(blob); // конвертирует Blob в base64 и вызывает onload

	reader.onload = function() {
	  link.href = reader.result; // url с данными
	  link.click();
	};

	}function downloadFile_sec(){
		let link = document.createElement("a");
	link.download = "page_'.$page_id.'.html";

	let blob = new Blob(['."'".$text."'".'], {type: "text/plain"});

	let reader = new FileReader();
	reader.readAsDataURL(blob); // конвертирует Blob в base64 и вызывает onload

	reader.onload = function() {
	  link.href = reader.result; // url с данными
	  link.click();
	};

	}
	function downloadFiles(){
		downloadFile();
		downloadFile_sec();
	}
	 </script>
	';
	if(empty($_GET)==false){
	echo'<script src="//js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
	<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
	<style type="text/css">
		body{
			font: 100% Arial;
		}


	</style>			
	<h1>Introduce CMS - Редактор страниц - Редактирование "'.$title.'"</h1>
	<form>
	</br> Файл интро(пишите default если не знаете что это)
	</br>
		<input type="text" name="intro" value="'.$intro.'"></input>
	</br> ID страницы(может быть буквенно-цифренным, не используйте уже существующий!)
	</br>
		<input type="text" name="id" value="'.$page_id.'"></input>
	</br> Название страницы</br>
			<input type="text" name="title" value="'.$title.'"></input>

		</br> Содержимое страницы</br>
		<textarea style=" color:white;width:900px; height: 300px;" name="text">'.$text.'</textarea>
		</br>	</br>
	';
	if($page_state =="on"){echo'
			<input type="checkbox" name="disable" checked>Отключить страницу</input>
			</br>
		<input type="submit" name=""></input>
	</form>	
	';}else{echo'
			<input type="checkbox" name="disable" >Отключить страницу</input>
			</br>
		<input type="submit" name=""></input>
	</form>	
	';}
	 echo'</br><hr></hr>Ссылка на страницу: (айпи/домен вашего сайта)/?id='.urlencode($page_id).'</br> <button onclick="downloadFiles();">Скачать файлы (загрузите их на сервер)</button></br>Подсказка. Вы можете скопировать ссылку на редактор, и при переходе по ней вы сможете скачать те же файлы.';


	}

	}
		}
		echo'<h3 style="font: 100% Arial Black; color:red;">ВНИМАНИЕ!!! РЕДАКТОР РАБОТАЕТ И ПРЕДОСТАВЛЯЕТСЯ "КАК-ЕСТЬ" В БЕТА-РЕЖИМЕ И ГЕНЕРИРУЕМЫЕ ИМ ФАЙЛЫ МОГУТ БЫТЬ НЕПРИГОДНЫМИ ДЛЯ Introduce CMS! АВТОР НЕ НЕСЁТ ОТВЕТСТВЕННОСТИ ЗА ВОЗМОЖНЫЙ УЩЕРБ.</h3>';
		?>
